from gamelogic import game_loop

#mastermind game
game_loop()